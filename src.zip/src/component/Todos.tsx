import Todo from "../module/Todo";
import TodoItem from "./TodoItem";
import classes from "./Todos.module.css"

const Todos: React.FC<{items:Todo[]; onRemoveTodoById: (todoId:string) => void}> = (props) => {
    return (<ul className={classes.todos}>
        {props.items.map((item) => <TodoItem key={item.id} txtItem={item.text} onRemoveTodo = {props.onRemoveTodoById.bind(null, item.id)}/>)}
    </ul>);    
}

export default Todos;