import { useRef } from "react";
import classes from './NewTodo.module.css';

const  NewTodo: React.FC<{ onAddTodo: (text:string) => void }> = (props:any) => {
    const inputRef = useRef<HTMLInputElement>(null);
    const submitHandler = (event:React.FormEvent) => {
       event.preventDefault();
       const enteredText = inputRef.current!.value;

       if(enteredText.trim().length === 0) {
           return;
       }

       props.onAddTodo(enteredText);
       inputRef.current!.value = "";
    }

    return (<form onSubmit={submitHandler} className={classes.form}>
        <label htmlFor="text">Insert New Course:</label>
        <input type="text"  id="text" ref={inputRef} />
        <button>Submit</button>
    </form>);
}

export default NewTodo;