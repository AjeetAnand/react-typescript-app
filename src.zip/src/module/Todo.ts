class Todo{
    text: string;
    id: string;

    constructor(itemText: string){
        this.text = itemText;
        this.id = Math.random().toString();
    }
}

export default Todo;