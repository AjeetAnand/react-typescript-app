import Todos from './component/Todos';
import './App.css';
import Todo from './module/Todo';
import NewTodo from './component/NewTodo';
import { useState } from 'react';

function App() {
  let todosList:Todo[]= [new Todo("Learn React"), new Todo("Learn TypeScript"), new Todo("Learn NextJS")];
  
  let [todos, setTodos] = useState<Todo[]>([]);
  //todos.concat(todosList);
  const onAddNewTodo = (todoText:string) => {
    console.log(">>>>>>>>>>>>>>>>>>> : "+todoText);
    setTodos((oldTodo)=> {
    return  oldTodo.concat(new Todo(todoText))})
  }

  const onRemoveTodoHandler = (todoId:string) =>{
    setTodos((oldTodo)=>{
      return oldTodo.filter(todo => todo.id !== todoId )
    })
  }

  return (
    <div className="App">
      <NewTodo onAddTodo = {onAddNewTodo}/>
      <Todos items={todos} onRemoveTodoById={onRemoveTodoHandler}/>
    </div>
  );
}

export default App;
